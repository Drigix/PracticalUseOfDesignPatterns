package org.example.services.decorator;

public interface ITextVacuum {

    String slice(String text);
}
