package org.example.services.template;

import java.util.Map;

public class StatisticaNLPImpl extends StatisticaTemplateMethod{

    @Override
    public Map<String, Integer> executeAll(String text) {
        return resultMap;
    }
}
