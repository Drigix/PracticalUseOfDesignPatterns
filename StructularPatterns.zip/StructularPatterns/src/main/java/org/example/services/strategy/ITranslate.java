package org.example.services.strategy;

public interface ITranslate {

    String translate(String text);
}
