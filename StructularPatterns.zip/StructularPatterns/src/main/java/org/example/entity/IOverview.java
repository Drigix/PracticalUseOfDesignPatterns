package org.example.entity;

public interface IOverview {

    void makeOverview(Car c);
    void changeOil(Car c);
    void changeFilters(Car c);
}
